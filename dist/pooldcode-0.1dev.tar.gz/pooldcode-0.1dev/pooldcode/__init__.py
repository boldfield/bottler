from pooldcode.app import App
app = App(__name__)
